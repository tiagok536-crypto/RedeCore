package com.rede.core;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class Economia {

    private final RedeCore p;
    private final Map<UUID, Double> saldo = new HashMap<>();

    public Economia(RedeCore p) {
        this.p = p;
    }

    public void load(YamlConfiguration d) {
        ConfigurationSection s = d.getConfigurationSection("saldo");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            try {
                saldo.put(UUID.fromString(k), s.getDouble(k));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save(YamlConfiguration d) {
        for (Map.Entry<UUID, Double> e : saldo.entrySet()) {
            d.set("saldo." + e.getKey(), e.getValue());
        }
    }

    public double get(UUID u) {
        return saldo.getOrDefault(u, p.getConfig().getDouble("dinheiro-inicial", 1000));
    }

    public void set(UUID u, double v) {
        saldo.put(u, Math.max(0, v));
    }

    public void add(UUID u, double v) {
        set(u, get(u) + v);
    }

    public boolean take(UUID u, double v) {
        if (get(u) < v) return false;
        set(u, get(u) - v);
        return true;
    }

    public static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) {
            v /= 1000;
            i++;
        }
        if (i == 0) return String.valueOf((long) v);
        return String.format(Locale.US, "%.2f", v).replaceAll("\\.?0+$", "") + suf[i];
    }
}
