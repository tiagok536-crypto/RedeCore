package com.rede.core;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

import static com.rede.core.RedeCore.cor;

public class Vender implements Listener {

    static class Holder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final String[] SUFIXOS = {"_SWORD", "_PICKAXE", "_AXE", "_SHOVEL", "_HOE",
            "_HELMET", "_CHESTPLATE", "_LEGGINGS", "_BOOTS"};
    private static final Set<String> EXTRAS = Set.of("BOW", "CROSSBOW", "TRIDENT", "SHIELD", "ELYTRA",
            "MACE", "FISHING_ROD", "SHEARS", "FLINT_AND_STEEL", "CARROT_ON_A_STICK",
            "WARPED_FUNGUS_ON_A_STICK", "BRUSH", "SPYGLASS", "WOLF_ARMOR");

    private final RedeCore p;
    private final Set<UUID> tudo = new HashSet<>();

    public Vender(RedeCore p) {
        this.p = p;
    }

    public static boolean proibido(Material m) {
        String n = m.name();
        for (String s : SUFIXOS) if (n.endsWith(s)) return true;
        return EXTRAS.contains(n);
    }

    public double preco(Material m) {
        if (proibido(m)) return 0;
        return p.getConfig().getDouble("precos." + m.name(), 0);
    }

    // ---------- menu ----------
    private ItemStack item(Material m, String nome, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.setDisplayName(cor(nome));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(cor(s));
        im.setLore(l);
        it.setItemMeta(im);
        return it;
    }

    public void abrir(Player pl) {
        Inventory inv = Bukkit.createInventory(new Holder(), 27, cor("&8Vender"));
        atualizar(pl, inv);
        pl.openInventory(inv);
    }

    private void atualizar(Player pl, Inventory inv) {
        ItemStack vidro = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, vidro);
        boolean vip = p.ehVip(pl);
        boolean completo = vip && tudo.contains(pl.getUniqueId());

        inv.setItem(11, item(Material.BOOK, "&cNao vendemos",
                "&7Espadas, picaretas, machados,", "&7pas, enxadas, armaduras,",
                "&7arcos, escudos e similares."));
        inv.setItem(13, item(Material.EMERALD, "&a&lVENDER",
                completo ? "&7Vende &fTODO o inventario" : "&7Vende o item da &fmao",
                completo ? "&7e os drops dos seus spawners." : "&7(VIP: ative a alavanca para vender tudo)",
                "", "&eClique para vender"));
        inv.setItem(15, item(Material.DROPPER, "&6Vender drops dos spawners",
                "&7Vende tudo que seus spawners geraram.", "", "&eClique para vender"));
        if (vip) {
            inv.setItem(22, item(Material.LEVER, "&e&lPainel VIP",
                    "&7Vender inventario completo: " + (completo ? "&aATIVADO" : "&cDESATIVADO"),
                    "", "&eClique para alternar"));
        }
    }

    // ---------- vendas ----------
    private double venderArmazem(Player pl) {
        Map<Material, Long> arm = p.spawners.armazem(pl.getUniqueId());
        double t = 0;
        for (Map.Entry<Material, Long> e : arm.entrySet()) t += preco(e.getKey()) * e.getValue();
        arm.entrySet().removeIf(e -> preco(e.getKey()) > 0);
        return t;
    }

    private void pagar(Player pl, double total) {
        if (total <= 0) {
            pl.sendMessage(p.msg("&cNao ha nada para vender!"));
            return;
        }
        p.economia.add(pl.getUniqueId(), total);
        pl.sendMessage(p.msg("&aVendido por &f$" + Economia.fmt(total)
                + "&a! Saldo: &f$" + Economia.fmt(p.economia.get(pl.getUniqueId()))));
    }

    private void vender(Player pl) {
        PlayerInventory inv = pl.getInventory();
        double total = 0;
        if (p.ehVip(pl) && tudo.contains(pl.getUniqueId())) {
            for (int i = 0; i < 36; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null) continue;
                double pr = preco(it.getType());
                if (pr <= 0) continue;
                total += pr * it.getAmount();
                inv.setItem(i, null);
            }
            total += venderArmazem(pl);
        } else {
            ItemStack it = inv.getItemInMainHand();
            double pr = preco(it.getType());
            if (pr > 0) {
                total = pr * it.getAmount();
                inv.setItemInMainHand(null);
            }
        }
        pagar(pl, total);
    }

    @EventHandler
    public void clique(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        Player pl = (Player) e.getWhoClicked();
        Inventory top = e.getView().getTopInventory();
        switch (e.getSlot()) {
            case 13 -> vender(pl);
            case 15 -> pagar(pl, venderArmazem(pl));
            case 22 -> {
                if (!p.ehVip(pl)) return;
                if (!tudo.remove(pl.getUniqueId())) tudo.add(pl.getUniqueId());
                atualizar(pl, top);
            }
            default -> {
            }
        }
    }

    @EventHandler
    public void arrastar(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void sair(PlayerQuitEvent e) {
        tudo.remove(e.getPlayer().getUniqueId());
    }
}
