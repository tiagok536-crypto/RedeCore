package com.rede.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

import static com.rede.core.RedeCore.cor;

public class SpawnerManager implements Listener {

    static class Dado {
        final UUID dono;
        final EntityType tipo;

        Dado(UUID dono, EntityType tipo) {
            this.dono = dono;
            this.tipo = tipo;
        }
    }

    static class Loja implements InventoryHolder {
        final List<String> tipos = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final RedeCore p;
    private final NamespacedKey key;
    private final Map<String, Dado> blocos = new HashMap<>();
    private final Map<UUID, Map<Material, Long>> armazem = new HashMap<>();
    private final Random rnd = new Random();
    private BukkitTask task;

    public SpawnerManager(RedeCore p) {
        this.p = p;
        this.key = new NamespacedKey(p, "spawner_tipo");
    }

    // ---------- dados ----------
    private String chave(Location l) {
        return l.getWorld().getName() + ";" + l.getBlockX() + ";" + l.getBlockY() + ";" + l.getBlockZ();
    }

    public Map<Material, Long> armazem(UUID u) {
        return armazem.computeIfAbsent(u, k -> new HashMap<>());
    }

    public void load(YamlConfiguration d) {
        for (String s : d.getStringList("spawners")) {
            String[] a = s.split(";");
            if (a.length != 6) continue;
            try {
                blocos.put(a[0] + ";" + a[1] + ";" + a[2] + ";" + a[3],
                        new Dado(UUID.fromString(a[4]), EntityType.valueOf(a[5])));
            } catch (IllegalArgumentException ignored) {
            }
        }
        ConfigurationSection arm = d.getConfigurationSection("armazem");
        if (arm != null) {
            for (String u : arm.getKeys(false)) {
                ConfigurationSection m = arm.getConfigurationSection(u);
                if (m == null) continue;
                try {
                    Map<Material, Long> mapa = armazem(UUID.fromString(u));
                    for (String mat : m.getKeys(false)) {
                        Material mm = Material.matchMaterial(mat);
                        if (mm != null) mapa.put(mm, m.getLong(mat));
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    public void save(YamlConfiguration d) {
        List<String> l = new ArrayList<>();
        for (Map.Entry<String, Dado> e : blocos.entrySet()) {
            l.add(e.getKey() + ";" + e.getValue().dono + ";" + e.getValue().tipo.name());
        }
        d.set("spawners", l);
        for (Map.Entry<UUID, Map<Material, Long>> e : armazem.entrySet()) {
            for (Map.Entry<Material, Long> m : e.getValue().entrySet()) {
                if (m.getValue() > 0) d.set("armazem." + e.getKey() + "." + m.getKey().name(), m.getValue());
            }
        }
    }

    // ---------- geracao ----------
    public void iniciar() {
        long ticks = Math.max(1, p.getConfig().getLong("spawners.intervalo-segundos", 5)) * 20L;
        task = Bukkit.getScheduler().runTaskTimer(p, this::gerar, ticks, ticks);
    }

    public void parar() {
        if (task != null) task.cancel();
    }

    private void gerar() {
        ConfigurationSection tipos = p.getConfig().getConfigurationSection("spawners.tipos");
        if (tipos == null) return;
        double mult = p.getConfig().getDouble("spawners.taxa-geracao", 1.0);
        long limite = p.getConfig().getLong("spawners.limite-armazenamento", 100000);
        for (Dado d : blocos.values()) {
            Map<Material, Long> arm = armazem(d.dono);
            for (Map<?, ?> m : tipos.getMapList(d.tipo.name() + ".drops")) {
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null) continue;
                int min = RedeCore.num(m.get("min"), 0);
                int max = RedeCore.num(m.get("max"), 1);
                double chance = RedeCore.dbl(m.get("chance"), 1.0);
                if (rnd.nextDouble() > chance) continue;
                double q = (min + rnd.nextInt(Math.max(1, max - min + 1))) * mult;
                long n = (long) q;
                if (rnd.nextDouble() < q - n) n++;
                if (n <= 0) continue;
                arm.put(mat, Math.min(limite, arm.getOrDefault(mat, 0L) + n));
            }
        }
    }

    // ---------- item ----------
    public String nome(String tipo) {
        String n = p.getConfig().getString("spawners.tipos." + tipo + ".nome");
        if (n != null) return n;
        String t = tipo.toLowerCase().replace('_', ' ');
        return Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    public ItemStack criarItem(EntityType t, int qtd) {
        ItemStack it = new ItemStack(Material.SPAWNER, qtd);
        ItemMeta im = it.getItemMeta();
        if (im instanceof BlockStateMeta bsm) {
            BlockState st = bsm.getBlockState();
            if (st instanceof CreatureSpawner cs) {
                cs.setSpawnedType(t);
                bsm.setBlockState(cs);
            }
        }
        im.setDisplayName(cor("&e&l" + nome(t.name()) + " Spawner"));
        im.setLore(List.of(cor("&7Gera itens virtualmente."), cor("&7Venda com &f/vender&7.")));
        im.getPersistentDataContainer().set(key, PersistentDataType.STRING, t.name());
        it.setItemMeta(im);
        return it;
    }

    public void entregar(Player pl, ItemStack it) {
        for (ItemStack sobra : pl.getInventory().addItem(it).values()) {
            pl.getWorld().dropItemNaturally(pl.getLocation(), sobra);
        }
    }

    // ---------- blocos ----------
    @EventHandler(ignoreCancelled = true)
    public void colocar(BlockPlaceEvent e) {
        ItemMeta im = e.getItemInHand().getItemMeta();
        if (im == null) return;
        String t = im.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (t == null) return;
        EntityType tipo;
        try {
            tipo = EntityType.valueOf(t);
        } catch (IllegalArgumentException x) {
            return;
        }
        Block b = e.getBlockPlaced();
        BlockState st = b.getState();
        if (st instanceof CreatureSpawner cs) {
            cs.setSpawnedType(tipo);
            cs.setRequiredPlayerRange(0); // desliga o spawn fisico, a geracao e virtual
            cs.setMaxNearbyEntities(0);
            cs.update(true, false);
        }
        blocos.put(chave(b.getLocation()), new Dado(e.getPlayer().getUniqueId(), tipo));
        e.getPlayer().sendMessage(p.msg("&aSpawner de &f" + nome(t) + " &acolocado!"));
    }

    @EventHandler(ignoreCancelled = true)
    public void quebrar(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        Dado d = blocos.get(chave(b.getLocation()));
        if (d == null) return;
        Player pl = e.getPlayer();
        if (!d.dono.equals(pl.getUniqueId()) && !pl.hasPermission("rede.admin")) {
            e.setCancelled(true);
            pl.sendMessage(p.msg("&cEsse spawner pertence a outro jogador!"));
            return;
        }
        e.setDropItems(false);
        e.setExpToDrop(0);
        blocos.remove(chave(b.getLocation()));
        World w = b.getWorld();
        w.dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), criarItem(d.tipo, 1));
    }

    @EventHandler(ignoreCancelled = true)
    public void explosao(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> blocos.containsKey(chave(b.getLocation())));
    }

    // ---------- loja /spawner ----------
    public void abrirLoja(Player pl) {
        ConfigurationSection tipos = p.getConfig().getConfigurationSection("spawners.tipos");
        if (tipos == null) {
            pl.sendMessage(p.msg("&cNenhum spawner configurado."));
            return;
        }
        Loja holder = new Loja();
        holder.tipos.addAll(tipos.getKeys(false));
        int linhas = Math.min(6, Math.max(1, (holder.tipos.size() + 8) / 9));
        Inventory inv = Bukkit.createInventory(holder, linhas * 9, cor("&8Loja de Spawners"));
        for (int i = 0; i < holder.tipos.size() && i < linhas * 9; i++) {
            String t = holder.tipos.get(i);
            Material icone = Material.matchMaterial(t + "_SPAWN_EGG");
            ItemStack it = new ItemStack(icone != null ? icone : Material.SPAWNER);
            ItemMeta im = it.getItemMeta();
            im.setDisplayName(cor("&e&l" + nome(t)));
            List<String> lore = new ArrayList<>();
            lore.add(cor("&7Preco: &a$" + Economia.fmt(tipos.getDouble(t + ".preco"))));
            lore.add(cor("&7Drops:"));
            for (Map<?, ?> m : tipos.getMapList(t + ".drops")) {
                lore.add(cor("&8- &f" + m.get("material")));
            }
            lore.add("");
            lore.add(cor("&eClique: &fcomprar 1"));
            lore.add(cor("&eShift+Clique: &fcomprar 8"));
            im.setLore(lore);
            it.setItemMeta(im);
            inv.setItem(i, it);
        }
        pl.openInventory(inv);
    }

    @EventHandler
    public void clique(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Loja loja)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (slot < 0 || slot >= loja.tipos.size()) return;
        Player pl = (Player) e.getWhoClicked();
        String t = loja.tipos.get(slot);
        int qtd = e.isShiftClick() ? 8 : 1;
        double total = p.getConfig().getDouble("spawners.tipos." + t + ".preco") * qtd;
        if (!p.economia.take(pl.getUniqueId(), total)) {
            pl.sendMessage(p.msg("&cVoce precisa de &a$" + Economia.fmt(total) + "&c. Saldo: &a$"
                    + Economia.fmt(p.economia.get(pl.getUniqueId()))));
            return;
        }
        try {
            entregar(pl, criarItem(EntityType.valueOf(t), qtd));
        } catch (IllegalArgumentException ex) {
            p.economia.add(pl.getUniqueId(), total);
            return;
        }
        pl.sendMessage(p.msg("&aComprou &f" + qtd + "x " + nome(t) + " &apor &f$" + Economia.fmt(total)));
    }

    @EventHandler
    public void arrastar(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Loja) e.setCancelled(true);
    }
}
