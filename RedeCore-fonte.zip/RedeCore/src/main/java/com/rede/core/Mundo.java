package com.rede.core;

import org.bukkit.Chunk;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.EntitiesLoadEvent;

import java.util.EnumSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Remove mobs fortes e gera minerios novos. */
public class Mundo implements Listener {

    private static final Set<Material> TROCAVEIS = EnumSet.of(
            Material.STONE, Material.DEEPSLATE, Material.ANDESITE,
            Material.DIORITE, Material.GRANITE, Material.TUFF);

    private final RedeCore p;

    public Mundo(RedeCore p) {
        this.p = p;
    }

    private boolean bloqueado(EntityType t) {
        for (String s : p.getConfig().getStringList("mobs-bloqueados")) {
            if (s.equalsIgnoreCase(t.name())) return true;
        }
        return false;
    }

    @EventHandler(ignoreCancelled = true)
    public void spawn(CreatureSpawnEvent e) {
        if (bloqueado(e.getEntityType())) e.setCancelled(true);
    }

    @EventHandler
    public void entidades(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (bloqueado(en.getType())) en.remove();
        }
    }

    @EventHandler
    public void chunk(ChunkLoadEvent e) {
        if (!e.isNewChunk()) return;
        Chunk c = e.getChunk();
        Bukkit.getScheduler().runTask(p, () -> gerarMinerios(c));
    }

    private void gerarMinerios(Chunk c) {
        World w = c.getWorld();
        if (w.getEnvironment() != World.Environment.NORMAL) return;
        Random r = new Random(w.getSeed() ^ (c.getX() * 341873128712L) ^ (c.getZ() * 132897987541L));
        for (Map<?, ?> m : p.getConfig().getMapList("minerios")) {
            Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
            if (mat == null) continue;
            int veias = RedeCore.num(m.get("veias"), 1);
            int tam = RedeCore.num(m.get("tamanho"), 4);
            int yMin = Math.max(w.getMinHeight(), RedeCore.num(m.get("y-min"), -60));
            int yMax = Math.min(w.getMaxHeight() - 1, RedeCore.num(m.get("y-max"), 60));
            if (yMax < yMin) continue;
            Material deep = Material.matchMaterial("DEEPSLATE_" + mat.name());
            for (int v = 0; v < veias; v++) {
                int lx = r.nextInt(16), lz = r.nextInt(16);
                int y = yMin + r.nextInt(yMax - yMin + 1);
                for (int i = 0; i < tam; i++) {
                    Block b = w.getBlockAt(c.getX() * 16 + lx, y, c.getZ() * 16 + lz);
                    if (TROCAVEIS.contains(b.getType())) {
                        boolean ds = b.getType() == Material.DEEPSLATE && deep != null;
                        b.setType(ds ? deep : mat, false);
                    }
                    lx = Math.max(0, Math.min(15, lx + r.nextInt(3) - 1));
                    lz = Math.max(0, Math.min(15, lz + r.nextInt(3) - 1));
                    y = Math.max(yMin, Math.min(yMax, y + r.nextInt(3) - 1));
                }
            }
        }
    }
}
