package com.rede.core;

import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class RedeCore extends JavaPlugin {

    private File dataFile;
    public Economia economia;
    public SpawnerManager spawners;
    public Vender vender;
    public Placar placar;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);

        economia = new Economia(this);
        spawners = new SpawnerManager(this);
        vender = new Vender(this);
        placar = new Placar(this);
        economia.load(data);
        spawners.load(data);

        Comandos cmd = new Comandos(this);
        for (String n : List.of("vender", "spawner", "money", "eco")) {
            getCommand(n).setExecutor(cmd);
        }

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(spawners, this);
        pm.registerEvents(vender, this);
        pm.registerEvents(placar, this);
        pm.registerEvents(new Mundo(this), this);

        spawners.iniciar();
        placar.iniciar();
        getServer().getScheduler().runTaskTimer(this, this::salvar, 20L * 300, 20L * 300);
    }

    @Override
    public void onDisable() {
        placar.parar();
        salvar();
    }

    public void salvar() {
        YamlConfiguration data = new YamlConfiguration();
        economia.save(data);
        spawners.save(data);
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Nao foi possivel salvar data.yml: " + e.getMessage());
        }
    }

    public void recarregar() {
        reloadConfig();
        spawners.parar();
        spawners.iniciar();
    }

    public static String cor(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public String msg(String s) {
        return cor(getConfig().getString("prefixo", "&8[&6Rede&8] ") + s);
    }

    public boolean ehVip(Player p) {
        for (String perm : getConfig().getStringList("vip-permissoes")) {
            if (p.hasPermission(perm)) return true;
        }
        return false;
    }

    /** Cargo do jogador: mesma logica do plugin Cargos (permissao cargos.<id>). */
    public String cargo(Player p) {
        ConfigurationSection sec = getConfig().getConfigurationSection("cargos");
        if (sec != null) {
            for (String id : sec.getKeys(false)) {
                if (p.hasPermission("cargos." + id)) return sec.getString(id, id);
            }
        }
        return getConfig().getString("cargo-padrao", "&7Membros");
    }

    public static int num(Object o, int def) {
        return o instanceof Number n ? n.intValue() : def;
    }

    public static double dbl(Object o, double def) {
        return o instanceof Number n ? n.doubleValue() : def;
    }
}
