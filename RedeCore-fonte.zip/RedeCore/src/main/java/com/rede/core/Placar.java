package com.rede.core;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.rede.core.RedeCore.cor;

public class Placar implements Listener {

    private static final int LINHAS = 8;

    static class Board {
        Scoreboard sb;
        Objective obj;
        final Team[] teams = new Team[LINHAS];
    }

    private final RedeCore p;
    private final Map<UUID, Board> boards = new HashMap<>();
    private BukkitTask task;

    public Placar(RedeCore p) {
        this.p = p;
    }

    public void iniciar() {
        task = Bukkit.getScheduler().runTaskTimer(p, () -> {
            for (Player pl : Bukkit.getOnlinePlayers()) atualizar(pl);
        }, 20L, 20L);
    }

    public void parar() {
        if (task != null) task.cancel();
        for (Player pl : Bukkit.getOnlinePlayers()) {
            pl.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    private Board criar() {
        Board b = new Board();
        b.sb = Bukkit.getScoreboardManager().getNewScoreboard();
        b.obj = b.sb.registerNewObjective("rede", "dummy", "Rede");
        b.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        for (int i = 0; i < LINHAS; i++) {
            String entry = "" + ChatColor.values()[i] + ChatColor.RESET;
            b.teams[i] = b.sb.registerNewTeam("l" + i);
            b.teams[i].addEntry(entry);
            b.obj.getScore(entry).setScore(LINHAS - i);
        }
        return b;
    }

    private void atualizar(Player pl) {
        Board b = boards.computeIfAbsent(pl.getUniqueId(), k -> criar());
        if (pl.getScoreboard() != b.sb) pl.setScoreboard(b.sb);
        b.obj.setDisplayName(cor(p.getConfig().getString("placar.titulo", "&6&lSERVER")));
        String[] l = {
                "&r ",
                "&fCargo: " + p.cargo(pl),
                "&r  ",
                "&fDinheiro: &a$" + Economia.fmt(p.economia.get(pl.getUniqueId())),
                "&fMortes: &c" + pl.getStatistic(Statistic.DEATHS),
                "&fAbates: &e" + pl.getStatistic(Statistic.PLAYER_KILLS),
                "&r   ",
                p.getConfig().getString("placar.rodape", "")
        };
        for (int i = 0; i < LINHAS; i++) {
            b.teams[i].setPrefix(cor(l[i].isEmpty() ? " " : l[i]));
        }
    }

    @EventHandler
    public void entrar(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(p, () -> atualizar(e.getPlayer()), 5L);
    }

    @EventHandler
    public void sair(PlayerQuitEvent e) {
        boards.remove(e.getPlayer().getUniqueId());
    }
}
