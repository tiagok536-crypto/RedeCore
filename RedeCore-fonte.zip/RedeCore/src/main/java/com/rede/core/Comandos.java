package com.rede.core;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class Comandos implements CommandExecutor {

    private final RedeCore p;

    public Comandos(RedeCore p) {
        this.p = p;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase()) {
            case "vender" -> {
                if (!(s instanceof Player pl)) return semConsole(s);
                p.vender.abrir(pl);
            }
            case "spawner" -> spawner(s, a);
            case "money" -> money(s, a);
            case "eco" -> eco(s, a);
            default -> {
            }
        }
        return true;
    }

    private boolean semConsole(CommandSender s) {
        s.sendMessage(p.msg("&cApenas jogadores."));
        return true;
    }

    private void spawner(CommandSender s, String[] a) {
        if (a.length == 0) {
            if (s instanceof Player pl) p.spawners.abrirLoja(pl);
            else semConsole(s);
            return;
        }
        if (!s.hasPermission("rede.admin")) {
            s.sendMessage(p.msg("&cSem permissao."));
            return;
        }
        if (a[0].equalsIgnoreCase("reload")) {
            p.recarregar();
            s.sendMessage(p.msg("&aConfiguracao recarregada."));
        } else if (a[0].equalsIgnoreCase("give") && a.length >= 3) {
            Player alvo = Bukkit.getPlayerExact(a[1]);
            if (alvo == null) {
                s.sendMessage(p.msg("&cJogador offline."));
                return;
            }
            if (p.getConfig().getConfigurationSection("spawners.tipos." + a[2].toUpperCase()) == null) {
                s.sendMessage(p.msg("&cTipo nao configurado."));
                return;
            }
            int qtd = 1;
            if (a.length >= 4) {
                try {
                    qtd = Math.max(1, Math.min(64, Integer.parseInt(a[3])));
                } catch (NumberFormatException ignored) {
                }
            }
            p.spawners.entregar(alvo, p.spawners.criarItem(EntityType.valueOf(a[2].toUpperCase()), qtd));
            s.sendMessage(p.msg("&aEntregue &f" + qtd + "x " + a[2].toUpperCase() + " &apara &f" + alvo.getName()));
        } else {
            s.sendMessage(p.msg("&7Uso: /spawner [give <jogador> <tipo> [qtd] | reload]"));
        }
    }

    private void money(CommandSender s, String[] a) {
        if (a.length >= 1) {
            OfflinePlayer o = Bukkit.getOfflinePlayer(a[0]);
            s.sendMessage(p.msg("&7Saldo de &f" + a[0] + "&7: &a$" + Economia.fmt(p.economia.get(o.getUniqueId()))));
        } else if (s instanceof Player pl) {
            pl.sendMessage(p.msg("&7Seu saldo: &a$" + Economia.fmt(p.economia.get(pl.getUniqueId()))));
        } else semConsole(s);
    }

    private void eco(CommandSender s, String[] a) {
        if (!s.hasPermission("rede.admin")) {
            s.sendMessage(p.msg("&cSem permissao."));
            return;
        }
        if (a.length < 3) {
            s.sendMessage(p.msg("&7Uso: /eco <give|take|set> <jogador> <valor>"));
            return;
        }
        double v;
        try {
            v = Double.parseDouble(a[2]);
        } catch (NumberFormatException e) {
            s.sendMessage(p.msg("&cValor invalido."));
            return;
        }
        OfflinePlayer o = Bukkit.getOfflinePlayer(a[1]);
        switch (a[0].toLowerCase()) {
            case "give" -> p.economia.add(o.getUniqueId(), v);
            case "take" -> p.economia.set(o.getUniqueId(), p.economia.get(o.getUniqueId()) - v);
            case "set" -> p.economia.set(o.getUniqueId(), v);
            default -> {
                s.sendMessage(p.msg("&7Uso: /eco <give|take|set> <jogador> <valor>"));
                return;
            }
        }
        s.sendMessage(p.msg("&aSaldo de &f" + a[1] + "&a agora: &f$" + Economia.fmt(p.economia.get(o.getUniqueId()))));
    }
}
